﻿// File: MiuSeederTool.Core/MiuDerivationSeeder.cs
// Descrizione: Classe responsabile della generazione e del seeding delle stringhe MIU nel database.
// Aggiornato per utilizzare una startString casuale dal masterDerivablePool per le SolutionPath.
// Target Framework: .NET Framework 4.8

using MasterLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MiuSeederTool.Core
{
    /// <summary>
    /// Enumera i tipi di algoritmo di ricerca che possono essere utilizzati per trovare percorsi.
    /// </summary>
    public enum PathFindingAlgorithm
    {
        BFS,
        DFS
    }

    /// <summary>
    /// Rappresenta un singolo passo in un percorso di derivazione MIU.
    /// Contiene la stringa dello stato, l'ID della regola applicata per raggiungerlo,
    /// e la stringa dello stato genitore.
    /// </summary>
    public class PathStepInfo
    {
        public string StateString { get; set; } // La stringa MIU per questo stato
        public long? AppliedRuleID { get; set; } // L'ID della regola applicata per raggiungere questo stato (null per lo stato iniziale)
        public string ParentStateString { get; set; } // La stringa dello stato genitore (null per lo stato iniziale)
        public int Depth { get; set; } // La profondità (numero di passi dal punto di partenza) di questo stato
    }

    /// <summary>
    /// Gestisce la generazione e l'inizializzazione del database con stringhe MIU.
    /// </summary>
    public class MiuDerivationSeeder
    {
        private readonly SeederDbAccess _dbAccess;
        private readonly MiuStringHelper _miuStringHelper;
        private readonly Logger _logger;
        private readonly Random _random;
        private readonly int _globalMaxStringLength;

        // Stringhe iniziali da cui iniziare la derivazione per il master pool
        private static readonly List<string> InitialSeedStrings = new List<string>
        {
            "MI",
            "MII",
            "MIU",
            "MIIII",
            "MUI",
            "MIIIIU",
            "MIIIIIIII",
            "MUUII",
            "MUUIIU"
        };

        /// <summary>
        /// Inizializza una nuova istanza della classe MiuDerivationSeeder.
        /// </summary>
        /// <param name="dbAccess">L'istanza per l'accesso al database.</param>
        /// <param name="miuStringHelper">L'istanza per l'applicazione delle regole MIU.</param>
        /// <param name="logger">L'istanza del logger.</param>
        /// <param name="globalMaxStringLength">La lunghezza massima consentita per le stringhe MIU.</param>
        public MiuDerivationSeeder(SeederDbAccess dbAccess, MiuStringHelper miuStringHelper, Logger logger, int globalMaxStringLength)
        {
            _dbAccess = dbAccess ?? throw new ArgumentNullException(nameof(dbAccess));
            _miuStringHelper = miuStringHelper ?? throw new ArgumentNullException(nameof(miuStringHelper));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
            _random = new Random();
            _globalMaxStringLength = globalMaxStringLength;

            _logger.Log(LogLevel.INFO, "[MiuDerivationSeeder] Initialized.", false);
        }

        /// <summary>
        /// Inizializza completamente il database con stringhe MIU di vari tipi.
        /// </summary>
        /// <param name="numTotalStrings">Il numero totale di stringhe da generare.</param>
        /// <param name="maxDerivationDepthForSeeding">La profondità massima di derivazione da esplorare per il seeding.</param>
        /// <param name="cancellationToken">Token per annullare l'operazione.</param>
        /// <param name="pathAlgorithm">L'algoritmo da usare per trovare i percorsi di soluzione (BFS o DFS).</param>
        public async Task InitializeFullDatabaseAsync(int numTotalStrings, int maxDerivationDepthForSeeding, CancellationToken cancellationToken, PathFindingAlgorithm pathAlgorithm)
        {
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Starting full database initialization. Total strings target: {numTotalStrings}. Path algorithm: {pathAlgorithm}.", false);
            Console.WriteLine($"Starting full database initialization. Total strings target: {numTotalStrings} (using {pathAlgorithm} for paths)...");

            int targetDerivableCount = 20;
            int targetSolutionPathCount = 500;

            List<SeederMiuState> statesToInsert = new List<SeederMiuState>();
            HashSet<string> uniqueStringsTracker = new HashSet<string>();

            int poolGenerationLimit = Math.Max(targetDerivableCount * 5, targetSolutionPathCount * 50);
            poolGenerationLimit = Math.Max(poolGenerationLimit, numTotalStrings * 2);

            HashSet<string> masterDerivablePool = new HashSet<string>();
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Generating master pool of derivable strings (max length {_globalMaxStringLength}, depth {maxDerivationDepthForSeeding}, pool limit {poolGenerationLimit})...", false);
            Console.WriteLine($"Generating master pool of derivable strings...");

            foreach (string startString in InitialSeedStrings)
            {
                if (cancellationToken.IsCancellationRequested) break;

                HashSet<string> currentBranchDerivables = await GenerateLimitedUniqueStringsAsync(
                    startString,
                    maxDerivationDepthForSeeding,
                    poolGenerationLimit,
                    _globalMaxStringLength,
                    cancellationToken
                );
                foreach (string s in currentBranchDerivables)
                {
                    masterDerivablePool.Add(s);
                    if (masterDerivablePool.Count >= poolGenerationLimit) break;
                }
                if (masterDerivablePool.Count >= poolGenerationLimit) break;
            }
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Master pool generated with {masterDerivablePool.Count} unique derivable strings.", false);
            Console.WriteLine($"Master pool generated with {masterDerivablePool.Count} unique derivable strings.");

            if (masterDerivablePool.Count == 0)
            {
                _logger.Log(LogLevel.WARNING, "[MiuDerivationSeeder] Master pool of derivable strings is empty. Cannot guarantee Derivable or SolutionPath types.", false);
                Console.WriteLine("Master pool of derivable strings is empty. Cannot guarantee Derivable or SolutionPath types.");
            }

            // --- FASE 2: Preparazione di stringhe SolutionPath (Tipo 2) ---
            List<string> candidateSolutionTargets = masterDerivablePool
                                                    .OrderBy(s => _random.Next())
                                                    .Where(s => s.Length <= _globalMaxStringLength)
                                                    .ToList();

            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Preparing {targetSolutionPathCount} 'SolutionPath' strings from {candidateSolutionTargets.Count} candidates using {pathAlgorithm}.", false);
            Console.WriteLine($"Preparing {targetSolutionPathCount} 'SolutionPath' strings using {pathAlgorithm}.");

            int actualSolutionPathCount = 0;
            foreach (string target in candidateSolutionTargets)
            {
                if (cancellationToken.IsCancellationRequested || actualSolutionPathCount >= targetSolutionPathCount) break;

                if (uniqueStringsTracker.Contains(target)) continue;

                // NUOVA LOGICA: Seleziona una startString casuale dal masterDerivablePool
                string randomStartString = masterDerivablePool.ElementAt(_random.Next(masterDerivablePool.Count));

                List<PathStepInfo> solutionPath = await FindSolutionPathInternally(randomStartString, target, _globalMaxStringLength, maxDerivationDepthForSeeding * 5, cancellationToken, pathAlgorithm);

                if (solutionPath != null && solutionPath.Any())
                {
                    _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder] Path found for '{randomStartString}' -> '{target}'. Path length: {solutionPath.Count}.", false);
                    foreach (PathStepInfo pathStep in solutionPath) // Itera sui PathStepInfo
                    {
                        if (cancellationToken.IsCancellationRequested || actualSolutionPathCount >= targetSolutionPathCount) break;

                        // Usa la stringa dallo step del percorso
                        string pathString = pathStep.StateString;

                        if (uniqueStringsTracker.Add(pathString))
                        {
                            statesToInsert.Add(new SeederMiuState
                            {
                                CurrentString = pathString,
                                StringLength = pathString.Length,
                                DeflateString = SeederDbAccess.CompressMiuString(pathString),
                                Hash = SeederDbAccess.CalculateSha256Hash(pathString),
                                DiscoveryTime_Int = new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds(),
                                DiscoveryTime_Text = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
                                UsageCount = 0,
                                SeedingType = SeedingType.SolutionPath
                            });
                            actualSolutionPathCount++;
                            _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder] String '{pathString}' prepared as 'SolutionPath'. Count: {actualSolutionPathCount}/{targetSolutionPathCount}", false);
                        }
                    }
                }
                else
                {
                    _logger.Log(LogLevel.WARNING, $"[MiuDerivationSeeder] No path found from '{randomStartString}' to '{target}' using {pathAlgorithm}.", false);
                }
            }
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Prepared {actualSolutionPathCount} unique 'SolutionPath' strings.", false);
            Console.WriteLine($"Prepared {actualSolutionPathCount} unique 'SolutionPath' strings.");

            // --- FASE 3: Preparazione di stringhe Derivable (Tipo 1) ---
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Preparing {targetDerivableCount} 'Derivable' strings.", false);
            Console.WriteLine($"Preparing {targetDerivableCount} 'Derivable' strings.");

            int actualDerivableCount = 0;
            foreach (string derivableString in masterDerivablePool.OrderBy(s => _random.Next()))
            {
                if (cancellationToken.IsCancellationRequested || actualDerivableCount >= targetDerivableCount) break;

                if (uniqueStringsTracker.Add(derivableString))
                {
                    statesToInsert.Add(new SeederMiuState
                    {
                        CurrentString = derivableString,
                        StringLength = derivableString.Length,
                        DeflateString = SeederDbAccess.CompressMiuString(derivableString),
                        Hash = SeederDbAccess.CalculateSha256Hash(derivableString),
                        DiscoveryTime_Int = new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds(),
                        DiscoveryTime_Text = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
                        UsageCount = 0,
                        SeedingType = SeedingType.Derivable
                    });
                    actualDerivableCount++;
                    _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder] String '{derivableString}' prepared as 'Derivable'. Count: {actualDerivableCount}/{targetDerivableCount}", false);
                }
            }
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Prepared {actualDerivableCount} unique 'Derivable' strings.", false);
            Console.WriteLine($"Prepared {actualDerivableCount} unique 'Derivable' strings.");

            // --- FASE 4: Preparazione di stringhe Random per raggiungere il totale ---
            int currentTotalStrings = statesToInsert.Count;
            int randomStringsNeeded = numTotalStrings - currentTotalStrings;

            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Preparing {randomStringsNeeded} 'Random' strings to reach total of {numTotalStrings}.", false);
            Console.WriteLine($"Preparing {randomStringsNeeded} 'Random' strings to reach total of {numTotalStrings}.");

            int actualRandomCount = 0;
            int randomAttempts = 0;
            int maxRandomAttempts = randomStringsNeeded * 5;

            while (actualRandomCount < randomStringsNeeded && randomAttempts < maxRandomAttempts && !cancellationToken.IsCancellationRequested)
            {
                string randomString = GenerateRandomMiuLikeString(_globalMaxStringLength);
                if (uniqueStringsTracker.Add(randomString))
                {
                    statesToInsert.Add(new SeederMiuState
                    {
                        CurrentString = randomString,
                        StringLength = randomString.Length,
                        DeflateString = SeederDbAccess.CompressMiuString(randomString),
                        Hash = SeederDbAccess.CalculateSha256Hash(randomString),
                        DiscoveryTime_Int = new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds(),
                        DiscoveryTime_Text = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss"),
                        UsageCount = 0,
                        SeedingType = SeedingType.Random
                    });
                    actualRandomCount++;
                    _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder] String '{randomString}' prepared as 'Random'. Count: {actualRandomCount}/{randomStringsNeeded}", false);
                }
                randomAttempts++;
            }
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Prepared {actualRandomCount} unique 'Random' strings.", false);
            Console.WriteLine($"Prepared {actualRandomCount} unique 'Random' strings.");

            // --- FASE 5: Inserimento finale di tutte le stringhe nel database ---
            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Inserting all {statesToInsert.Count} unique strings into the database.", false);
            Console.WriteLine($"Inserting all {statesToInsert.Count} unique strings into the database.");

            int insertedFinalCount = 0;
            foreach (SeederMiuState state in statesToInsert.OrderBy(s => _random.Next()))
            {
                if (cancellationToken.IsCancellationRequested) break;

                _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder] DEBUG (Pre-InsertDbAccess): String '{state.CurrentString}'. SeedingType (oggetto): {state.SeedingType}. Valore int: {(int)state.SeedingType}", false);

                await _dbAccess.InsertMiuStateAsync(state);
                insertedFinalCount++;
                _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder] Inserito: '{state.CurrentString}' (Tipo: {state.SeedingType}) ({insertedFinalCount}/{statesToInsert.Count})", false);
            }

            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder] Full database initialization completed. Inserted {insertedFinalCount} total strings.", false);
            Console.WriteLine($"Full database initialization completed. Inserted {insertedFinalCount} total strings.");
            Console.WriteLine($"Final counts: Derivable: {actualDerivableCount}, SolutionPath: {actualSolutionPathCount}, Random: {actualRandomCount}.");
        }

        /// <summary>
        /// Genera un numero specificato di stringhe MIU uniche derivate da una stringa iniziale,
        /// esplorando fino a una profondità massima e rispettando una lunghezza massima.
        /// Restituisce le stringhe man mano che vengono scoperte, fino al limite maxStringsToCollect.
        /// Questo metodo è progettato per popolare il database iniziale con diverse stringhe.
        /// </summary>
        /// <param name="initialString">La stringa MIU iniziale (es. "MI").</param>
        /// <param name="maxDepth">La profondità massima da esplorare per trovare stringhe.</param>
        /// <param name="maxStringsToCollect">Il numero massimo di stringhe uniche da raccogliere.</param>
        /// <param name="maxLength">La lunghezza massima consentita per le stringhe generate.</param>
        /// <param name="cancellationToken">Token per annullare l'operazione.</param>
        /// <returns>Un HashSet di stringhe MIU uniche trovate che rispettano la lunghezza massima.</returns>
        public async Task<HashSet<string>> GenerateLimitedUniqueStringsAsync(string initialString, int maxDepth, int maxStringsToCollect, int maxLength, CancellationToken cancellationToken)
        {
            HashSet<string> collectedUniqueStrings = new HashSet<string>();
            if (maxStringsToCollect <= 0) return collectedUniqueStrings;
            if (maxDepth < 0) return collectedUniqueStrings;

            if (initialString.Length > maxLength)
            {
                _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder.GenerateLimitedUniqueStringsAsync] Stringa iniziale '{initialString}' (lunghezza {initialString.Length}) supera maxLength {maxLength}. Non verrà esplorata.", false);
                return collectedUniqueStrings;
            }

            Queue<(string currentString, int depth)> queue = new Queue<(string, int)>();
            HashSet<string> visited = new HashSet<string>();

            queue.Enqueue((currentString: initialString, depth: 0));
            visited.Add(initialString);

            if (!string.IsNullOrEmpty(initialString) && collectedUniqueStrings.Count < maxStringsToCollect)
            {
                collectedUniqueStrings.Add(initialString);
            }

            while (queue.Any() && collectedUniqueStrings.Count < maxStringsToCollect && !cancellationToken.IsCancellationRequested)
            {
                var (current, currentDepth) = queue.Dequeue();

                if (currentDepth >= maxDepth)
                {
                    continue;
                }

                var derivedStrings = _miuStringHelper.ApplyAllRules(current);

                foreach (var derived in derivedStrings)
                {
                    if (cancellationToken.IsCancellationRequested) break;

                    if (derived.Length > maxLength)
                    {
                        _logger.Log(LogLevel.DEBUG, $"[MiuDerivationSeeder.GenerateLimitedUniqueStringsAsync] Scartata stringa '{derived}' (lunghezza {derived.Length}) perché supera maxLength {maxLength}.", false);
                        continue;
                    }

                    if (!visited.Contains(derived))
                    {
                        visited.Add(derived);
                        collectedUniqueStrings.Add(derived);
                        if (collectedUniqueStrings.Count >= maxStringsToCollect) break;

                        queue.Enqueue((currentString: derived, depth: currentDepth + 1));
                    }
                }
                await Task.Delay(1);
            }

            _logger.Log(LogLevel.INFO, $"[MiuDerivationSeeder.GenerateLimitedUniqueStringsAsync] Trovate {collectedUniqueStrings.Count} stringhe uniche fino a profondità {maxDepth} e lunghezza massima {maxLength} (max {maxStringsToCollect} richieste) partendo da '{initialString}'.", false);
            return collectedUniqueStrings;
        }

        /// <summary>
        /// Trova un percorso di derivazione da una stringa iniziale a una stringa target utilizzando l'algoritmo specificato.
        /// Restituisce una lista di PathStepInfo che rappresentano il percorso, o null se non trovato.
        /// Questo metodo è stato adattato per usare PathStepInfo e gestire BFS/DFS.
        /// </summary>
        /// <param name="startString">La stringa di partenza.</param>
        /// <param name="targetString">La stringa target da raggiungere.</param>
        /// <param name="maxLength">La lunghezza massima consentita per le stringhe nel percorso.</param>
        /// <param name="maxDepth">La profondità massima di ricerca.</param>
        /// <param name="cancellationToken">Token per annullare l'operazione.</param>
        /// <param name="algorithm">L'algoritmo di ricerca del percorso da utilizzare (BFS o DFS).</param>
        /// <returns>Una lista di PathStepInfo che rappresentano il percorso, o null se non trovato.</returns>
        private async Task<List<PathStepInfo>> FindSolutionPathInternally(string startString, string targetString, int maxLength, int maxDepth, CancellationToken cancellationToken, PathFindingAlgorithm algorithm)
        {
            _logger.Log(LogLevel.INFO, $"[FindSolutionPathInternally] Starting {algorithm} search from '{startString}' to '{targetString}' (Max Length: {maxLength}, Max Depth: {maxDepth}).", false);

            if (startString == targetString)
            {
                _logger.Log(LogLevel.INFO, $"[FindSolutionPathInternally] Start string is already target string: '{startString}'.", false);
                return new List<PathStepInfo> { new PathStepInfo { StateString = startString, Depth = 0, AppliedRuleID = null, ParentStateString = null } };
            }

            if (algorithm == PathFindingAlgorithm.BFS)
            {
                Queue<(string currentString, List<PathStepInfo> path)> queue = new Queue<(string, List<PathStepInfo>)>();
                HashSet<string> visited = new HashSet<string>();

                queue.Enqueue((currentString: startString, path: new List<PathStepInfo> { new PathStepInfo { StateString = startString, Depth = 0, AppliedRuleID = null, ParentStateString = null } }));
                visited.Add(startString);

                while (queue.Any() && !cancellationToken.IsCancellationRequested)
                {
                    var (current, path) = queue.Dequeue();

                    if (path.Count - 1 >= maxDepth) // current depth is path.Count - 1
                    {
                        continue;
                    }

                    var derivedStrings = _miuStringHelper.ApplyAllRules(current);

                    foreach (var derived in derivedStrings)
                    {
                        if (cancellationToken.IsCancellationRequested) return null;

                        if (derived.Length > maxLength)
                        {
                            _logger.Log(LogLevel.DEBUG, $"[BFS-Internal] Derived string '{derived}' (length {derived.Length}) exceeds max length {maxLength}. Skipping.", false);
                            continue;
                        }

                        if (derived == targetString)
                        {
                            var newPathStep = new PathStepInfo { StateString = derived, Depth = path.Count, AppliedRuleID = null, ParentStateString = current }; // RuleID e ParentStateString possono essere migliorati qui
                            List<PathStepInfo> newPath = new List<PathStepInfo>(path) { newPathStep };
                            _logger.Log(LogLevel.INFO, $"[BFS-Internal] Path found for '{targetString}'! Path length: {newPath.Count - 1}.", false);
                            return newPath;
                        }

                        if (visited.Add(derived))
                        {
                            var newPathStep = new PathStepInfo { StateString = derived, Depth = path.Count, AppliedRuleID = null, ParentStateString = current }; // RuleID e ParentStateString possono essere migliorati qui
                            List<PathStepInfo> newPath = new List<PathStepInfo>(path) { newPathStep };
                            queue.Enqueue((currentString: derived, path: newPath));
                            _logger.Log(LogLevel.DEBUG, $"[BFS-Internal] Enqueued '{derived}' (depth: {newPath.Count - 1}). Queue size: {queue.Count}.", false);
                        }
                    }
                    await Task.Delay(1);
                }
            }
            else if (algorithm == PathFindingAlgorithm.DFS)
            {
                // Implementazione DFS
                Stack<(string currentString, List<PathStepInfo> path)> stack = new Stack<(string, List<PathStepInfo>)>();
                HashSet<string> visited = new HashSet<string>();

                stack.Push((currentString: startString, path: new List<PathStepInfo> { new PathStepInfo { StateString = startString, Depth = 0, AppliedRuleID = null, ParentStateString = null } }));
                visited.Add(startString);

                while (stack.Any() && !cancellationToken.IsCancellationRequested)
                {
                    var (current, path) = stack.Pop();

                    if (path.Count - 1 >= maxDepth) // current depth is path.Count - 1
                    {
                        continue;
                    }

                    var derivedStrings = _miuStringHelper.ApplyAllRules(current);

                    // For DFS, push in reverse order to explore the first derived path deeper
                    foreach (var derived in derivedStrings.Reverse())
                    {
                        if (cancellationToken.IsCancellationRequested) return null;

                        if (derived.Length > maxLength)
                        {
                            _logger.Log(LogLevel.DEBUG, $"[DFS-Internal] Derived string '{derived}' (length {derived.Length}) exceeds max length {maxLength}. Skipping.", false);
                            continue;
                        }

                        if (derived == targetString)
                        {
                            var newPathStep = new PathStepInfo { StateString = derived, Depth = path.Count, AppliedRuleID = null, ParentStateString = current }; // RuleID e ParentStateString possono essere migliorati qui
                            List<PathStepInfo> newPath = new List<PathStepInfo>(path) { newPathStep };
                            _logger.Log(LogLevel.INFO, $"[DFS-Internal] Path found for '{targetString}'! Path length: {newPath.Count - 1}.", false);
                            return newPath;
                        }

                        if (visited.Add(derived))
                        {
                            var newPathStep = new PathStepInfo { StateString = derived, Depth = path.Count, AppliedRuleID = null, ParentStateString = current }; // RuleID e ParentStateString possono essere migliorati qui
                            List<PathStepInfo> newPath = new List<PathStepInfo>(path) { newPathStep };
                            stack.Push((currentString: derived, path: newPath));
                            _logger.Log(LogLevel.DEBUG, $"[DFS-Internal] Pushed '{derived}' (depth: {newPath.Count - 1}). Stack size: {stack.Count}.", false);
                        }
                    }
                    await Task.Delay(1);
                }
            }

            _logger.Log(LogLevel.INFO, $"[FindSolutionPathInternally] No solution found from '{startString}' to '{targetString}' using {algorithm} within limits.", false);
            return null; // Percorso non trovato
        }

        /// <summary>
        /// Genera una stringa casuale "MIU-like" di lunghezza casuale.
        /// </summary>
        /// <param name="maxLength">La lunghezza massima per la stringa casuale.</param>
        /// <returns>Una stringa casuale composta da M, I, U.</returns>
        private string GenerateRandomMiuLikeString(int maxLength)
        {
            int length = _random.Next(1, maxLength + 1);
            StringBuilder sb = new StringBuilder();
            char[] chars = { 'M', 'I', 'U' };

            sb.Append('M');
            if (length > 1)
            {
                for (int i = 1; i < length; i++)
                {
                    sb.Append(chars[_random.Next(chars.Length)]);
                }
            }
            return sb.ToString();
        }
    }
}
